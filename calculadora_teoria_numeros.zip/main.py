"""Calculadora CLI de Teoria dos Números."""

import number_theory as nt

MAX_SIEVE = 10_000_000

MENU = """
--- Calculadora de Teoria dos Números ---
1. MDC
2. MMC
3. Exponenciação Modular
4. Inverso Modular
5. É Primo?
6. Primos até N (Crivo)
7. Fatores Primos
Q. Sair
"""


def read_int(prompt):
    """Lê um inteiro, repetindo até receber uma entrada válida."""
    while True:
        raw = input(prompt).strip()
        try:
            return int(raw)
        except ValueError:
            print(f"Erro: '{raw}' não é um número inteiro válido. Tente novamente.")


def op_gcd():
    a = read_int("Digite o primeiro número: ")
    b = read_int("Digite o segundo número: ")
    print(f"Resultado: MDC({a}, {b}) = {nt.get_gcd(a, b)}")


def op_lcm():
    a = read_int("Digite o primeiro número: ")
    b = read_int("Digite o segundo número: ")
    if a == 0 or b == 0:
        print("Aviso: o MMC com zero é considerado 0 por convenção.")
    print(f"Resultado: MMC({a}, {b}) = {nt.get_lcm(a, b)}")


def op_modexp():
    base = read_int("Digite a base: ")
    exp = read_int("Digite o expoente: ")
    mod = read_int("Digite o módulo: ")
    if mod == 0:
        print("Erro: divisão por zero — o módulo não pode ser 0.")
        return
    if mod < 0:
        print("Erro: o módulo deve ser um inteiro positivo.")
        return
    try:
        result = nt.modular_exponentiation(base, exp, mod)
    except ValueError as e:
        print(f"Erro: {e}")
        return
    print(f"Resultado: {base}^{exp} mod {mod} = {result}")


def op_modinv():
    a = read_int("Digite o número a: ")
    m = read_int("Digite o módulo m: ")
    if m == 0:
        print("Erro: divisão por zero — o módulo não pode ser 0.")
        return
    if m <= 1:
        print("Erro: o módulo deve ser um inteiro maior que 1.")
        return
    inverse = nt.modular_inverse(a, m)
    if inverse is None:
        g = nt.get_gcd(a, m)
        print(
            f"Aviso: o inverso de {a} módulo {m} não existe, "
            f"pois MDC({a}, {m}) = {g} ≠ 1 (não são coprimos)."
        )
        return
    print(f"Resultado: o inverso de {a} módulo {m} é {inverse}  "
          f"(verificação: {a} * {inverse} ≡ {(a * inverse) % m} mod {m})")


def op_is_prime():
    n = read_int("Digite o número: ")
    if nt.is_prime(n):
        print(f"Resultado: {n} é primo.")
    elif n < 2:
        print(f"Resultado: {n} não é primo (primos são inteiros maiores ou iguais a 2).")
    else:
        print(f"Resultado: {n} não é primo (é composto).")


def op_sieve():
    limit = read_int("Digite o limite N: ")
    if limit < 2:
        print("Resultado: não há primos até esse limite.")
        return
    if limit > MAX_SIEVE:
        print(f"Aviso: limite muito grande. Use um valor até {MAX_SIEVE:,}.".replace(",", "."))
        return
    primes = nt.sieve_of_eratosthenes(limit)
    print(f"Resultado: {len(primes)} primos até {limit}:")
    print(", ".join(map(str, primes)))


def op_factors():
    n = read_int("Digite o número: ")
    if n < 2:
        print("Erro: a fatoração exige um inteiro maior ou igual a 2.")
        return
    factors = nt.get_prime_factors(n)
    if len(factors) == 1:
        print(f"Resultado: {n} é primo, não há decomposição além dele mesmo.")
        return
    print(f"Resultado: {n} = {' x '.join(map(str, factors))}")


OPERATIONS = {
    "1": op_gcd,
    "2": op_lcm,
    "3": op_modexp,
    "4": op_modinv,
    "5": op_is_prime,
    "6": op_sieve,
    "7": op_factors,
}


def main():
    while True:
        print(MENU)
        choice = input("Selecione uma opção: ").strip().upper()
        if choice == "Q":
            print("Até logo!")
            break
        operation = OPERATIONS.get(choice)
        if operation is None:
            print("Opção inválida. Escolha de 1 a 7 ou Q para sair.")
            continue
        try:
            operation()
        except (KeyboardInterrupt, EOFError):
            print("\nOperação cancelada.")


if __name__ == "__main__":
    main()

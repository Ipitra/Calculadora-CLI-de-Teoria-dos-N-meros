"""Funções de teoria dos números implementadas manualmente."""


def get_gcd(a, b):
    """MDC pelo algoritmo Euclidiano. Sempre retorna um valor >= 0."""
    a, b = abs(a), abs(b)
    while b != 0:
        a, b = b, a % b
    return a


def get_lcm(a, b):
    """MMC calculado a partir do MDC: |a*b| / MDC(a, b). MMC com zero é 0."""
    if a == 0 or b == 0:
        return 0
    return abs(a // get_gcd(a, b) * b)


def is_prime(n):
    """Divisão por tentativa otimizada: testa divisores até a raiz de n."""
    if n < 2:
        return False
    if n < 4:  # 2 e 3
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:  # equivale a i <= sqrt(n), sem usar float
        if n % i == 0 or n % (i + 2) == 0:  # candidatos da forma 6k ± 1
            return False
        i += 6
    return True


def get_prime_factors(n):
    """Retorna a lista de fatores primos de n (com repetição, em ordem).

    Levanta ValueError se n < 2.
    """
    if n < 2:
        raise ValueError("A fatoração exige um inteiro maior ou igual a 2.")
    factors = []
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    d = 3
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 2
    if n > 1:  # o que sobrou é primo
        factors.append(n)
    return factors


def extended_gcd(a, b):
    """Euclides estendido: retorna (g, x, y) tal que a*x + b*y = g = MDC(a, b)."""
    old_r, r = a, b
    old_x, x = 1, 0
    old_y, y = 0, 1
    while r != 0:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_x, x = x, old_x - q * x
        old_y, y = y, old_y - q * y
    return old_r, old_x, old_y


def modular_inverse(a, m):
    """Inverso multiplicativo de a módulo m.

    Retorna None se o inverso não existe (a e m não coprimos).
    Levanta ValueError se o módulo for inválido (m <= 1).
    """
    if m <= 1:
        raise ValueError("O módulo deve ser um inteiro maior que 1.")
    g, x, _ = extended_gcd(a % m, m)
    if g != 1:
        return None
    return x % m


def modular_exponentiation(base, exp, mod):
    """(base ** exp) % mod por elevação ao quadrado e multiplicação.

    Expoentes negativos usam o inverso modular de base.
    Levanta ValueError se mod <= 0 ou se o inverso necessário não existir.
    """
    if mod <= 0:
        raise ValueError("O módulo deve ser um inteiro positivo.")
    if mod == 1:
        return 0
    if exp < 0:
        inverse = modular_inverse(base, mod)
        if inverse is None:
            raise ValueError(
                "Expoente negativo exige inverso de base módulo mod, "
                "mas ele não existe (não são coprimos)."
            )
        base, exp = inverse, -exp

    base %= mod
    result = 1
    while exp > 0:
        if exp & 1:  # bit atual do expoente é 1
            result = (result * base) % mod
        base = (base * base) % mod
        exp >>= 1
    return result


def sieve_of_eratosthenes(limit):
    """Lista de todos os primos <= limit (Crivo de Eratóstenes)."""
    if limit < 2:
        return []
    is_p = bytearray([1]) * (limit + 1)
    is_p[0] = is_p[1] = 0
    i = 2
    while i * i <= limit:
        if is_p[i]:
            for j in range(i * i, limit + 1, i):
                is_p[j] = 0
        i += 1
    return [n for n in range(2, limit + 1) if is_p[n]]
